<?php

require_once __DIR__ . "/client.class.php";
require_once __DIR__ . "/model.class.php";

require_once __DIR__ . "/rate.class.php";
